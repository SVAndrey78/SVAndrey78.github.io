﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let bg_list = ['bg_1.png','bg_2.png', 'bg_3.png','bg_4.png', ];	       
        let bg_index = 0;

        function bg_switching() {
            bg_index++;
            if (bg_index >= bg_list.length) bg_index = 0;
            normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
        }
		
       let pointernumber = 0
       let totalpointers = 2

       function click_pointer() {
           pointernumber=(pointernumber+1) % (totalpointers+1);

           //call hands function to change to correct hands
           call_change_Hands(pointernumber);
       }
     
         
       // Give handsnumber. Must exist
       function call_change_Hands(handsnumber) {
          switch (handsnumber) {

 
              case 1:
                 hourstring='hour_2.png';
                 minutestring='minute_2.png';
                 secondstring='secunde_2.png'; break;
              case 2:
                 hourstring='hour_3.png';
                 minutestring='minute_3.png';
                 secondstring='secunde_3.png'; break;				 
              default:				 
                 hourstring='hour_1.png';
                 minutestring='minute_1.png';
                 secondstring='secunde_1.png'; break;				 
            }

            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: hourstring,
            hour_centerX: 240,
            hour_centerY: 240,
            hour_posX: 240,
            hour_posY: 240,
            show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: minutestring,
            minute_centerX: 240,
            minute_centerY: 240,
            minute_posX: 240,
            minute_posY: 240,
            show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
            second_path: secondstring,
            second_centerX: 240,
            second_centerY: 240,
            second_posX: 240,
            second_posY: 240,
            show_level: hmUI.show_level.ONLY_NORMAL,
            });
       }

		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {	
            normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);			
          };
          if (zona1_num == 1) {
            normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);			
          };	  
		}	   
					
        let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 1
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {	
            Button_4.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
            Button_8.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_img.setProperty(hmUI.prop.VISIBLE, false);

			
          };
          if (zona2_num == 1) {
            Button_4.setProperty(hmUI.prop.VISIBLE, true);
			Button_7.setProperty(hmUI.prop.VISIBLE, true);
            Button_8.setProperty(hmUI.prop.VISIBLE, true);
			normal_image_img.setProperty(hmUI.prop.VISIBLE, true);

		
          };	  
		}	
		
        let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 3
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {	
            normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_max_min_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);			
          };
          if (zona3_num == 1) {
            normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_font.setProperty(hmUI.prop.VISIBLE, true);
            normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
         };			
          if (zona3_num == 2) {	
            normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
			normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);			
          };
          if (zona3_num == 3) {
            normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, true);		
          };	  
		}	

		let btn_zona4 = ''
        let zona4_num = 0
        let zona4_all = 1
		
		function click_zona4() {
		  zona4_num = (zona4_num + 1) % (zona4_all + 1);
          if (zona4_num == 0) {	
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
          };
          if (zona4_num == 1) {
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
          };	  
		}	  		
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_current_text_font = ''
        let normal_altitude_target_text_font = ''
        let normal_altimeter_current_text_font = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SUN', 'SAT', ];
        let normal_calorie_circle_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_compass_direction_pointer_img = ''
        let normal_image_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Rajdhani-Medium.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 440,
              h: 54,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Rajdhani-Medium.ttf; FontSize: 44; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 52,
              h: 52,
              text_size: 44,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Rajdhani-Medium.ttf; FontSize: 42; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 50,
              h: 50,
              text_size: 42,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Rajdhani-Medium.ttf; FontSize: 48
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 556,
              h: 74,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 140,
              w: 480,
              h: 41,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 124,
              y: 339,
              w: 233,
              h: 50,
              text_size: 44,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 124,
              y: 339,
              w: 233,
              h: 50,
              text_size: 44,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 124,
              y: 339,
              w: 233,
              h: 50,
              text_size: 44,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 124,
              y: 339,
              w: 233,
              h: 50,
              text_size: 44,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 150,
              y: 88,
              w: 89,
              h: 56,
              text_size: 42,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: MON, TUE, WED, THU, FRI, SUN, SAT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 358,
              // center_y: 240,
              // start_angle: -150,
              // end_angle: 150,
              // radius: 76,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFFAA0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 358,
              center_y: 240,
              start_angle: -150,
              end_angle: 150,
              radius: 70,
              line_width: 12,
              corner_flag: 3,
              color: 0xFFAA0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 162,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 298,
              y: 215,
              w: 120,
              h: 50,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 231,
              y: 88,
              w: 109,
              h: 56,
              text_size: 42,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 358,
              // center_y: 240,
              // start_angle: -150,
              // end_angle: 150,
              // radius: 76,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFFAA0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 358,
              center_y: 240,
              start_angle: -150,
              end_angle: 150,
              radius: 70,
              line_width: 12,
              corner_flag: 3,
              color: 0xFFAA0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 162,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 298,
              y: 215,
              w: 120,
              h: 50,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 121,
              // center_y: 240,
              // start_angle: -150,
              // end_angle: 150,
              // radius: 76,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFFAA0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 121,
              center_y: 240,
              start_angle: -150,
              end_angle: 150,
              radius: 70,
              line_width: 12,
              corner_flag: 3,
              color: 0xFFAA0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 45,
              y: 162,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 34,
              y: 215,
              w: 180,
              h: 50,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-Medium.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'secunde_1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'pointer_compass.png',
              // center_x: 240,
              // center_y: 240,
              // x: 80,
              // y: 80,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 80,
              pos_y: 240 - 80,
              center_x: 240,
              center_y: 240,
              src: 'pointer_compass.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 319,
              y: 221,
              w: 80,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 176,
              y: 346,
              w: 130,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 40,
              w: 103,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button_4.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 220,
              w: 155,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button_2.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 169,
              y: 99,
              w: 162,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 146,
              w: 76,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 283,
              w: 135,
              h: 36,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button_3.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_pointer();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 159,
              w: 99,
              h: 32,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button_1.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                bg_switching();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (screenType != hmSetting.screen_type.AOD) {
            normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);	
			Button_4.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
            Button_8.setProperty(hmUI.prop.VISIBLE, false);
			normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);	
			normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);			
            };
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '.' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '.' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

            };

            //end of ignored block
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 358,
                      center_y: 240,
                      start_angle: -150,
                      end_angle: 150,
                      radius: 70,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFFAA0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 358,
                      center_y: 240,
                      start_angle: -150,
                      end_angle: 150,
                      radius: 70,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFFAA0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 121,
                      center_y: 240,
                      start_angle: -150,
                      end_angle: 150,
                      radius: 70,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFFAA0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}