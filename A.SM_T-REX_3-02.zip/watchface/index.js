﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let normal_temper_pointer_progress_img_pointer = '' 
	    let forecastOn_num = 0		
		function click_forecastOn() {			  
         normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, true);
         normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
         normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
         normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
         normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
         normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, true);
         normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
         Button_1.setProperty(hmUI.prop.VISIBLE, false);
         Button_2.setProperty(hmUI.prop.VISIBLE, false);
         Button_3.setProperty(hmUI.prop.VISIBLE, true);	
          }	

        let forecastOff_num = 0		
		function click_forecastOff() {			  
         normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);
         normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
         normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
         normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
         normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
         normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
         Button_1.setProperty(hmUI.prop.VISIBLE, true);
         Button_2.setProperty(hmUI.prop.VISIBLE, true);
         Button_3.setProperty(hmUI.prop.VISIBLE, false);	
          }	
		  
        let activeOn_num = 0
		function click_activeOn() {			  
	    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
		normal_stress_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		normal_stand_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_weekly_text_font.setProperty(hmUI.prop.VISIBLE, true);
         Button_1.setProperty(hmUI.prop.VISIBLE, false);
         Button_2.setProperty(hmUI.prop.VISIBLE, false);
         Button_3.setProperty(hmUI.prop.VISIBLE, false);
         Button_4.setProperty(hmUI.prop.VISIBLE, false);
         Button_5.setProperty(hmUI.prop.VISIBLE, true);	 
          }		
        let activeOff_num = 0
		function click_activeOff() {			  
	    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_stress_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_stand_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_weekly_text_font.setProperty(hmUI.prop.VISIBLE, false);
         Button_1.setProperty(hmUI.prop.VISIBLE, true);
         Button_2.setProperty(hmUI.prop.VISIBLE, true);
         Button_3.setProperty(hmUI.prop.VISIBLE, false);
         Button_4.setProperty(hmUI.prop.VISIBLE, true);
         Button_5.setProperty(hmUI.prop.VISIBLE, false);
          }			  
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
        let normal_week_pointer_progress_date_pointer = ''
        let normal_temperature_current_text_font = ''
        let normal_fat_burning_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_day_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_time_hour_min_sec_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_spo2_current_text_font = ''
        let normal_stress_current_text_font = ''
        let normal_stand_current_text_font = ''
        let normal_pai_weekly_text_font = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_icon_img = ''
        let normal_forecast_date_week_font = new Array(5);
        let normal_forecast_date_week_font_Array = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
        let normal_forecast_high_text_font = new Array(5);
        let normal_forecast_low_text_font = new Array(5);
        let normal_forecast_image_progress_img_level = new Array(5);
        let normal_forecast_image_array = ['weather_00.png', 'weather_01.png', 'weather_02.png', 'weather_03.png', 'weather_04.png', 'weather_05.png', 'weather_06.png', 'weather_07.png', 'weather_08.png', 'weather_09.png', 'weather_10.png', 'weather_11.png', 'weather_12.png', 'weather_13.png', 'weather_14.png', 'weather_15.png', 'weather_16.png', 'weather_17.png', 'weather_18.png', 'weather_19.png', 'weather_20.png', 'weather_21.png', 'weather_22.png', 'weather_23.png', 'weather_24.png', 'weather_25.png', 'weather_26.png', 'weather_27.png', 'weather_28.png'];
        let normal_uvi_current_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_current_text_font = ''
        let normal_altitude_target_text_font = ''
        let normal_altimeter_current_text_font = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Netflix-(Bebas-Neue).ttf; FontSize: 56; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 67,
              h: 67,
              text_size: 56,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix-(Bebas-Neue).ttf; FontSize: 122
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1245,
              h: 160,
              text_size: 122,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix-(Bebas-Neue).ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 571,
              h: 66,
              text_size: 50,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix-(Bebas-Neue).ttf; FontSize: 52
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 597,
              h: 68,
              text_size: 52,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFF37FF9B,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 255,
              y: 99,
              w: 80,
              h: 54,
              text_size: 56,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Пн, Вт, Ср, Чт, Пт, Сб, Вс,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_1.png',
              center_x: 240,
              center_y: 240,
              posX: 240,
              posY: 240,
              start_angle: 10,
              end_angle: 71,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 270,
              y: 371,
              w: 110,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            normal_temper_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_2.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -194,
              end_angle: -251,
              invalid_visible: false,
              type: hmUI.data_type.WEATHER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script.js

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: -1,
              src: 'bt-off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 190,
              // end_angle: 251,
              // radius: 235,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFD6D6D6,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 190,
              end_angle: 251,
              radius: 231,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFD6D6D6,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 94,
              y: 371,
              w: 149,
              h: 54,
              text_size: 56,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 289,
              y: 99,
              w: 120,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 239,
              // start_angle: 289,
              // end_angle: 350,
              // radius: 236,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFD6D6D6,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 239,
              start_angle: 289,
              end_angle: 350,
              radius: 232,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFD6D6D6,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 97,
              y: 99,
              w: 120,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 190,
              w: 480,
              h: 120,
              text_size: 122,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_active.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 171,
              y: 405,
              w: 140,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 181,
              y: 270,
              w: 120,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 302,
              y: 270,
              w: 120,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 51,
              y: 270,
              w: 140,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 301,
              y: 127,
              w: 120,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 127,
              w: 120,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 61,
              y: 127,
              w: 120,
              h: 54,
              text_size: 56,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 30,
              // y: 91,
              // ColumnWidth: 85,
              // DaysCount: 5,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 30,
              y: 91,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // normal_forecast_icon_img = hmUI.createWidget(hmUI.widget.IMG_Options, {
              // x: -30,
              // y: -91,
              // src: 'bgForecast.png',
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_forecast_icon_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
              x: -30,
              y: -91,
              src: 'bgForecast.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 0,
              // y: 22,
              // w: 78,
              // h: 56,
              // text_size: 50,
              // char_space: 2,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/Netflix-(Bebas-Neue).ttf',
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: Пн, Вт, Ср, Чт, Пт, Сб, Вс,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 0 + i*85,
                  y: 22,
                  w: 78,
                  h: 56,
                  text_size: 50,
                  char_space: 2,
                  line_space: 0,
                  font: 'fonts/Netflix-(Bebas-Neue).ttf',
                  color: 0xFFFFFFFF,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: Пн, Вт, Ср, Чт, Пт, Сб, Вс,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_high_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 0,
              // y: 169,
              // w: 78,
              // h: 56,
              // text_size: 52,
              // char_space: 2,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/Netflix-(Bebas-Neue).ttf',
              // color: 0xFF37FF9B,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 0 + i*85,
                  y: 169,
                  w: 78,
                  h: 56,
                  text_size: 52,
                  char_space: 2,
                  line_space: 0,
                  font: 'fonts/Netflix-(Bebas-Neue).ttf',
                  color: 0xFF37FF9B,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 0,
              // y: 228,
              // w: 78,
              // h: 56,
              // text_size: 52,
              // char_space: 2,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/Netflix-(Bebas-Neue).ttf',
              // color: 0xFF2EA0BE,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 0 + i*85,
                  y: 228,
                  w: 78,
                  h: 56,
                  text_size: 52,
                  char_space: 2,
                  line_space: 0,
                  font: 'fonts/Netflix-(Bebas-Neue).ttf',
                  color: 0xFF2EA0BE,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: 74,
              // image_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*85,
                  y: 74,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_uvi_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 114,
              y: 374,
              w: 78,
              h: 56,
              text_size: 50,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 284,
              y: 374,
              w: 112,
              h: 56,
              text_size: 50,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 425,
              image_array: ["windD_1.png","windD_2.png","windD_3.png","windD_4.png","windD_5.png","windD_6.png","windD_7.png","windD_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 201,
              y: 374,
              w: 78,
              h: 56,
              text_size: 50,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFF37FF9B,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 43,
              y: 44,
              w: 200,
              h: 56,
              text_size: 50,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 273,
              y: 44,
              w: 122,
              h: 56,
              text_size: 50,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Netflix-(Bebas-Neue).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 203,
              y: 416,
              w: 76,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 280,
              y: 334,
              w: 100,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_forecastOn();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 100,
              w: 280,
              h: 280,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_forecastOff();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 111,
              y: 371,
              w: 115,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_activeOn();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 343,
              w: 300,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_activeOff();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

       if (screenType != hmSetting.screen_type.AOD) {
         normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);
         normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
         normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
         normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
         normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
         normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
         Button_3.setProperty(hmUI.prop.VISIBLE, false);	
		 
	    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_stress_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_stand_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_weekly_text_font.setProperty(hmUI.prop.VISIBLE, false);
        Button_5.setProperty(hmUI.prop.VISIBLE, false);		 
        };		
            // end user_script_end.js

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 5; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature + '°');
                };
                
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour:min:sec font');
              let normal_HourMinSecStr = format_hour.toString();
              normal_HourMinSecStr = normal_HourMinSecStr.padStart(2, '0');
              normal_HourMinSecStr = normal_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              if (!timeSensor.is24Hour) {
                if (hour > 11) normal_HourMinSecStr = 'pm ' + normal_HourMinSecStr
                else normal_HourMinSecStr = 'am ' + normal_HourMinSecStr
              };
              normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinSecStr );
            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 190,
                      end_angle: 251,
                      radius: 231,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFD6D6D6,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 239,
                      start_angle: 289,
                      end_angle: 350,
                      radius: 232,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFD6D6D6,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}