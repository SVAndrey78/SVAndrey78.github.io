﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


        let bg_list = [
            'time_1.png',
            'time_2.png',
            'time_3.png',
            'time_4.png',
        ];
        let bg_index = 0;

        function bg_switching() {
            bg_index++;
            if (bg_index >= bg_list.length) bg_index = 0;
            normal_image_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
        }
		
       let hourx = 240
       let houry = 240
       let minutex = 240
       let minutey = 240
       let secondx = 240
       let secondy = 240

       // Start color change
       let btncolor = ''
       let colornumber = 0
       let totalcolors = 3

       function click_Color() {
           colornumber=(colornumber+1) % (totalcolors+1);

           //call hands function to change to correct hands
           call_change_Hands(colornumber);
       }
     
         
       // Give handsnumber. Must exist
       function call_change_Hands(handsnumber) {
          switch (handsnumber) {

              case 1:
                 hourstring='h-2.png';
                 minutestring='m-2.png';
                 secondstring='s-2.png'; break;
              case 2:
                 hourstring='h-3.png';
                 minutestring='m-3.png';
                 secondstring='s-3.png'; break;
              case 3:
                 hourstring='h-4.png';
                 minutestring='m-4.png';
                 secondstring='s-4.png'; break;				 
              default:
                 hourstring='h-1.png';
                 minutestring='m-1.png';
                 secondstring='s-1.png'; break;				 
            }

            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: hourstring,
            hour_centerX: 240,
            hour_centerY: 240,
            hour_posX: hourx,
            hour_posY: houry,
            show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: minutestring,
            minute_centerX: 240,
            minute_centerY: 240,
            minute_posX: minutex,
            minute_posY: minutey,
            show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
            second_path: secondstring,
            second_centerX: 240,
            second_centerY: 240,
            second_posX: secondx,
            second_posY: secondy,
            show_level: hmUI.show_level.ONLY_NORMAL,
            });
       }

        let normal_image2_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''

        let normal_image_img = ''
        let normal_stand_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''		


		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {	
            normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);				
          };
          if (zona1_num == 1) {
            normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);	
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);	
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);				
          };	  
		}
		
		
		
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 1
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {	
            normal_image2_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);				
          };
          if (zona2_num == 1) {
            normal_image2_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);	
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);	
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);				
          };	  
		}	
	
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: alumni-sans-extrabold.ttf; FontSize: 62
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 702,
              h: 92,
              text_size: 62,
              char_space: 0,
              line_space: 0,
              font: 'fonts/alumni-sans-extrabold.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'time_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 176,
              y: 120,
              w: 138,
              h: 60,
              text_size: 62,
              char_space: 0,
              line_space: 0,
              font: 'fonts/alumni-sans-extrabold.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h-1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm-1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's-1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 207,
              w: 60,
              h: 60,
              text: '',
              color: 0xFF808080,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyNightMonitorScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 128,
              w: 120,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 46,
              w: 69,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                bg_switching();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'menu_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 360,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 360,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 360,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 243,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 243,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 243,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 117,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 117,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              dot_image: 'num_tchk.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 117,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			
			
			
            normal_image2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'menu_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 360,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 325,
              y: 353,
              image_array: ["wind_d_1.png","wind_d_2.png","wind_d_3.png","wind_d_4.png","wind_d_5.png","wind_d_6.png","wind_d_7.png","wind_d_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 243,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 243,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 117,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'num_grd.png',
              unit_tc: 'num_grd.png',
              unit_en: 'num_grd.png',
              negative_image: 'num_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 117,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'num_grd.png',
              unit_tc: 'num_grd.png',
              unit_en: 'num_grd.png',
              negative_image: 'num_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 117,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'num_grd.png',
              unit_tc: 'num_grd.png',
              unit_en: 'num_grd.png',
              negative_image: 'num_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 199,
              image_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 319,
              image_array: ["moon_00.png","moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			

           btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 200,
            y: 200,
            text: '',
            w: 80,
            h: 80,
            normal_src: 'empty.png',
            press_src: 'empty.png',
            click_func: () => {
             click_Color();
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          btncolor.setProperty(hmUI.prop.VISIBLE, true);

			btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207, //x кнопки
              y: 417, //y кнопки
              text: '',
              w: 68, //ширина кнопки
              h: 53, //высота кнопки
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                click_zona1();},
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);

            normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);	



			btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 420, //x кнопки
              y: 196, //y кнопки
              text: '',
              w: 64, //ширина кнопки
              h: 87, //высота кнопки
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                click_zona2();},
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);

            normal_image2_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);	
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);					

            // end user_script_end.js

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '.' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '.' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}